### test


$$ \sqrt
{
\frac
{\sum{(X_i-\overline{X})}^2}
{n-1}
} $$


![Alt text](./1497546491654.png)

